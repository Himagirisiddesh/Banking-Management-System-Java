package bank.model;

import java.time.LocalDateTime;

public class Transaction {
    private long txnId;
    private int userId;
    private String type; // deposit/withdraw/transfer_in/transfer_out
    private double amount;
    private LocalDateTime timestamp;
    private Integer counterpartyId; // nullable

    public long getTxnId() { return txnId; }
    public void setTxnId(long txnId) { this.txnId = txnId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public Integer getCounterpartyId() { return counterpartyId; }
    public void setCounterpartyId(Integer counterpartyId) { this.counterpartyId = counterpartyId; }
}