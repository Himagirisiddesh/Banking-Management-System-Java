
# Online Banking System (Console, Java + MySQL)

A resume-ready Java project demonstrating JDBC, transactions, password hashing, and a simple admin/customer flow.

## Features
- Register user (salted SHA-256 password).
- Admin approval required.
- Login (only approved users).
- Deposit, Withdraw, Transfer (ACID with JDBC transactions).
- Transaction history.

## Setup

1) Install MySQL and create schema:
```
mysql -u root -p < resources/schema.sql
```

2) Update DB credentials:
- Edit `src/bank/DB.java` and set `USER` and `PASSWORD` to your MySQL values.

3) Compile & Run (Java 11+):
```
cd src
javac bank/*.java bank/model/*.java bank/dao/*.java bank/service/*.java
java bank.App
```

## Notes
- This project uses no external libraries.
- For production-grade security, prefer BCrypt/Argon2 and use a web framework.
- You can extend this into a JSP/Servlets app by reusing the DAO/Service layers.
