package bank;

import bank.model.User;
import bank.service.BankService;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class App {
    private static final Scanner sc = new Scanner(System.in);
    private static final BankService service = new BankService();

    public static void main(String[] args) {
        System.out.println("=== Online Banking System (Console, Java + MySQL) ===");
        while (true) {
            System.out.println("\n1) Register");
            System.out.println("2) Login (Customer)");
            System.out.println("3) Admin: Approve Users");
            System.out.println("4) Exit");
            System.out.print("Choose: ");
            int ch = readInt();
            try {
                switch (ch) {
                    case 1 -> handleRegister();
                    case 2 -> handleLogin();
                    case 3 -> handleAdminApprove();
                    case 4 -> {
                        System.out.println("Goodbye!");
                        return;
                    }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void handleRegister() throws SQLException {
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Phone: ");
        String phone = sc.nextLine();
        System.out.print("Password: ");
        String pass = sc.nextLine();
        int id = service.register(name, email, phone, pass);
        System.out.println("Registered. Your user_id = " + id + ". Waiting for admin approval.");
    }

    private static void handleLogin() throws SQLException {
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Password: ");
        String pass = sc.nextLine();
        User u = service.login(email, pass);
        if (u == null) {
            System.out.println("Login failed (maybe not approved yet).");
            return;
        }
        System.out.println("Welcome, " + u.getName() + " (id=" + u.getUserId() + ")");
        while (true) {
            System.out.println("\n--- Customer Menu ---");
            System.out.println("1) Balance");
            System.out.println("2) Deposit");
            System.out.println("3) Withdraw");
            System.out.println("4) Transfer");
            System.out.println("5) Transactions");
            System.out.println("6) Logout");
            System.out.print("Choose: ");
            int ch = readInt();
            try {
                switch (ch) {
                    case 1 -> System.out.printf("Balance: %.2f%n", service.getBalance(u.getUserId()));
                    case 2 -> {
                        System.out.print("Amount: ");
                        double amt = readDouble();
                        service.deposit(u.getUserId(), amt);
                        System.out.println("Deposited.");
                    }
                    case 3 -> {
                        System.out.print("Amount: ");
                        double amt = readDouble();
                        service.withdraw(u.getUserId(), amt);
                        System.out.println("Withdrawn.");
                    }
                    case 4 -> {
                        System.out.print("To User ID: ");
                        int to = readInt();
                        System.out.print("Amount: ");
                        double amt = readDouble();
                        service.transfer(u.getUserId(), to, amt);
                        System.out.println("Transferred.");
                    }
                    case 5 -> {
                        List<String> txns = service.getTransactions(u.getUserId());
                        if (txns.isEmpty()) System.out.println("No transactions.");
                        else txns.forEach(System.out::println);
                    }
                    case 6 -> {
                        System.out.println("Logged out.");
                        return;
                    }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void handleAdminApprove() throws SQLException {
        System.out.println("=== Admin: Pending Users ===");
        var users = service.listUsers();
        boolean found = false;
        for (var u : users) {
            if (!u.isApproved()) {
                found = true;
                System.out.printf("UserID=%d | %s | %s | approved=%s%n",
                        u.getUserId(), u.getName(), u.getEmail(), u.isApproved());
            }
        }
        if (!found) {
            System.out.println("No pending approvals.");
            return;
        }
        System.out.print("Enter user_id to approve (0 to cancel): ");
        int id = readInt();
        if (id != 0) {
            service.approveUser(id);
            System.out.println("Approved user " + id);
        }
    }

    private static int readInt() {
        while (true) {
            try {
                String s = sc.nextLine();
                return Integer.parseInt(s.trim());
            } catch (Exception e) {
                System.out.print("Enter a valid integer: ");
            }
        }
    }

    private static double readDouble() {
        while (true) {
            try {
                String s = sc.nextLine();
                return Double.parseDouble(s.trim());
            } catch (Exception e) {
                System.out.print("Enter a valid number: ");
            }
        }
    }
}