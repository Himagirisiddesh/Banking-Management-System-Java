package bank.service;

import bank.DB;
import bank.SecurityUtil;
import bank.dao.TransactionDAO;
import bank.dao.UserDAO;
import bank.model.User;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class BankService {
    private final UserDAO userDAO = new UserDAO();
    private final TransactionDAO txnDAO = new TransactionDAO();

    // Registration
    public int register(String name, String email, String phone, String rawPassword) throws SQLException {
        if (userDAO.findByEmail(email) != null) {
            throw new IllegalArgumentException("Email already registered.");
        }
        String salt = SecurityUtil.generateSalt();
        String hash = SecurityUtil.hashPassword(rawPassword, salt);

        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPhone(phone);
        u.setSalt(salt);
        u.setPasswordHash(hash);
        u.setRole("customer");
        u.setBalance(0.0);
        u.setApproved(false); // requires admin approval

        return userDAO.create(u);
    }

    // Authentication (returns user if ok, else null)
    public User login(String email, String rawPassword) throws SQLException {
        User u = userDAO.findByEmail(email);
        if (u == null) return null;
        if (!u.isApproved()) return null;
        boolean ok = SecurityUtil.verifyPassword(rawPassword, u.getSalt(), u.getPasswordHash());
        return ok ? u : null;
    }

    // Admin approval
    public void approveUser(int userId) throws SQLException {
        userDAO.approveUser(userId);
    }

    // Deposit
    public void deposit(int userId, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        try (Connection con = DB.getConnection()) {
            con.setAutoCommit(false);
            try {
                userDAO.updateBalance(con, userId, amount);
                txnDAO.insert(con, userId, "deposit", amount, null);
                con.commit();
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        }
    }

    // Withdraw
    public void withdraw(int userId, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        try (Connection con = DB.getConnection()) {
            con.setAutoCommit(false);
            try {
                double bal = userDAO.getBalance(con, userId);
                if (bal < amount) throw new IllegalStateException("Insufficient balance");
                userDAO.updateBalance(con, userId, -amount);
                txnDAO.insert(con, userId, "withdraw", amount, null);
                con.commit();
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        }
    }

    // Transfer
    public void transfer(int fromUserId, int toUserId, double amount) throws SQLException {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        if (fromUserId == toUserId) throw new IllegalArgumentException("Cannot transfer to self");
        try (Connection con = DB.getConnection()) {
            con.setAutoCommit(false);
            try {
                double bal = userDAO.getBalance(con, fromUserId);
                if (bal < amount) throw new IllegalStateException("Insufficient balance");
                userDAO.updateBalance(con, fromUserId, -amount);
                userDAO.updateBalance(con, toUserId, amount);
                txnDAO.insert(con, fromUserId, "transfer_out", amount, toUserId);
                txnDAO.insert(con, toUserId, "transfer_in", amount, fromUserId);
                con.commit();
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        }
    }

    public double getBalance(int userId) throws SQLException {
        try (Connection con = DB.getConnection()) {
            return userDAO.getBalance(con, userId);
        }
    }

    public List<String> getTransactions(int userId) throws SQLException {
        return txnDAO.listByUser(userId);
    }

    public List<User> listUsers() throws SQLException {
        return userDAO.findAll();
    }

    public User getUserByEmail(String email) throws SQLException {
        return userDAO.findByEmail(email);
    }
}