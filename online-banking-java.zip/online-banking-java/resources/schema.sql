
-- Create database (run this once)
CREATE DATABASE IF NOT EXISTS bankdb;
USE bankdb;

-- Users table
CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(200) NOT NULL,
  salt VARCHAR(200) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'customer',
  balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  approved TINYINT(1) NOT NULL DEFAULT 0
);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
  txn_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('deposit','withdraw','transfer_in','transfer_out') NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  counterparty_id INT NULL,
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Optional: seed an admin (password = admin123)
-- NOTE: This uses SHA-256 + salt as implemented in SecurityUtil.java
-- Replace the hash/salt below with values printed by a helper if you add one.
