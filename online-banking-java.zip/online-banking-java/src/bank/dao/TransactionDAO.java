package bank.dao;

import bank.DB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public void insert(Connection con, int userId, String type, double amount, Integer counterpartyId) throws SQLException {
        String sql = "INSERT INTO transactions(user_id,type,amount,timestamp,counterparty_id) VALUES (?,?,?,NOW(),?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, type);
            ps.setDouble(3, amount);
            if (counterpartyId == null) ps.setNull(4, Types.INTEGER);
            else ps.setInt(4, counterpartyId);
            ps.executeUpdate();
        }
    }

    public List<String> listByUser(int userId) throws SQLException {
        String sql = "SELECT txn_id, type, amount, timestamp, counterparty_id FROM transactions WHERE user_id=? ORDER BY timestamp DESC";
        List<String> rows = new ArrayList<>();
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    long id = rs.getLong("txn_id");
                    String type = rs.getString("type");
                    double amount = rs.getDouble("amount");
                    Timestamp ts = rs.getTimestamp("timestamp");
                    int cp = rs.getInt("counterparty_id");
                    String cpStr = rs.wasNull() ? "-" : String.valueOf(cp);
                    rows.add(String.format("#%d | %-13s | %.2f | %s | CP: %s", id, type, amount, ts.toString(), cpStr));
                }
            }
        }
        return rows;
    }
}